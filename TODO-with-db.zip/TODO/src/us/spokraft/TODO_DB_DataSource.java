package us.spokraft;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import javax.transaction.*;
//import javax.websocket.Session;

import org.hibernate.*;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import javassist.bytecode.Descriptor.Iterator;

import org.springframework.context.annotation.Bean;

public class TODO_DB_DataSource implements TODO_DAO
{

	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public void save_or_update_task(TODO_Task t)
	{
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.saveOrUpdate(t);
		//session.delete(t);
		tx.commit();
		session.close();
	}

	@Override
	@Transactional
	public void delete_task(int id)
	{
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		TODO_Task t = (TODO_Task) session.load(TODO_Task.class, id);
		session.delete(t);
		tx.commit();
		session.close();

	}

	@Override
	public TODO_Task get_task(int task_id)
	{
		Session session = sessionFactory.openSession();
		TODO_Task t = (TODO_Task) session.load(TODO_Task.class, task_id);
		return t;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List get_all()
	{	
		Session session = sessionFactory.openSession();
		//List tasks = session.createNativeQuery("select * from TASK").list();
		List tasks = session.createQuery("from TODO_Task").list();
		session.close();
		
		//ArrayList<TODO_Task> res = new ArrayList<TODO_Task>();
		//for ( ListIterator iterator = tasks.listIterator(); iterator.hasNext(); )
		//   res.add((TODO_Task) iterator.next());
		   
		return tasks;
	}

}
