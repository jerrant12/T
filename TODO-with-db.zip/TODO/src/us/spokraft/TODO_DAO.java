package us.spokraft;

import java.util.List;

public interface TODO_DAO
{
	public void save_or_update_task(TODO_Task t);
	public void delete_task(int id);
	public TODO_Task get_task(int task_id);
	public List<TODO_Task> get_all();

}
