package us.spokraft;

import java.util.*;

public class TODO_List_DataSource implements TODO_DAO
{
	private List<TODO_Task> _data_store;
	private int _next_id;
	
	public TODO_List_DataSource()
	{
	    _data_store = new ArrayList<TODO_Task>(10);
	    _data_store.add(new TODO_Task(1, "Make pie"));
	    _data_store.add(new TODO_Task(2, "Eat pie"));
	    _data_store.add(new TODO_Task(3, "Be Happy pie"));
	    
	    _next_id = 4;
	}

	@Override
	public void save_or_update_task(TODO_Task t)
	{
		TODO_Task copy;
		int id = t.getId();
		if ( id == -1 )
		{
			copy = new TODO_Task(_next_id++, t.getItem() );
			
		    _data_store.add( copy );
		}
		else // otherwise update...
		{
		   copy = get_task(id);
		   copy.setItem(t.getItem());
		}

	}

	@Override
	public void delete_task(int id)
	{
		_data_store.remove(get_task(id));

	}

	@Override
	public TODO_Task get_task(int task_id)
	{
		ListIterator<TODO_Task> iterator = _data_store.listIterator();
		TODO_Task t;
		
		while ( iterator.hasNext())
		{
			t = iterator.next();
			if ( t.getId() == task_id )
			 return t;
		}
		
		
		return null;
	}

	@Override
	public List<TODO_Task> get_all()
	{
		return _data_store;
	}

}
