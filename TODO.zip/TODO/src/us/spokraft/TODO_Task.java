package us.spokraft;


public class TODO_Task
{
    private int id;
    private String item;
    
    public TODO_Task()
    {
      id = -1;
      item = "";
    }
    
    public TODO_Task(int id, String item)
    {
       this.id = id;
       this.item = item;
    }
    
    public void setId(int id)
    {
    	this.id = id;
    }
    
    public void setItem(String item)
    {
    	this.item = item;
    }
    
    public int getId()
    {
    	return id;
    }
    
    public String getItem()
    {
    	return item;
    }
    
    public boolean equals(Object o)
    {
    	if ( o instanceof TODO_Task )
    	{
    		TODO_Task t = (TODO_Task) o;
    		return item.equalsIgnoreCase(t.item);
    	}
    	return false;
    }

}
