package us.spokraft;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.portlet.ModelAndView;
//import org.springframework.ui.ModelMap;


@Controller
//@RequestMapping("/hello")
public class TODO_Controller
{
	
   //@Autowired
   private TODO_DAO _dao;
   
   public TODO_Controller(TODO_DAO d)
   {
	   _dao = d; // need to wire this in somehow...// I did! It was neat!
   }
   /*
   public void set_dao(TODO_DAO dao)
   {
     _dao = dao;
   }
   */
   
   @RequestMapping(value="/getJSON")
   public @ResponseBody List<TODO_Task> getJSON()
   {
	   return _dao.get_all();
   }
   
   @RequestMapping(value="/")
   public String printHello(ModelMap m)
   //public ModelAndView list_tasks()
	{
		m.addAttribute("list_tasks",  _dao.get_all());

		return "home";		
	}
  
   /*
   @RequestMapping(value="/")
   public ModelAndView list_tasks(ModelAndView model)
   {
	   model.addObject("list_tasks", _dao.get_all());
	   model.setViewName("home");
	   return model;
   }
   */
   @RequestMapping(value = "/new_task")
   public String new_task(ModelMap model)
   {
	  TODO_Task t = new TODO_Task();
	  model.addAttribute("task", t);
	  //.model.model.setView("new_task_form");
	  return "new_task_form";
   }
   /*
   @RequestMapping(value = "/new_task", method = RequestMethod.GET)
   public ModelAndView new_task(ModelAndView model)
   {
	  TODO_Task t = new TODO_Task();
	  model.addObject("task", t);
	  model.setView("new_task_form");
	  return model;
   }
   */
   
   
   @RequestMapping(value = "/save_or_update_task", method = RequestMethod.POST)
   public String save_or_update_task(@ModelAttribute("task") TODO_Task task)
   {
	_dao.save_or_update_task(task);
	//return "hello";
	return "redirect:/";
   }
   
   @RequestMapping(value = "delete_task", method = RequestMethod.GET)
   public String delete_task(HttpServletRequest request)
   {
	   int id = Integer.parseInt( request.getParameter("id"));
	   _dao.delete_task(id);
	   return "redirect:/";
   }
   
   @RequestMapping(value = "/edit_task", method = RequestMethod.GET )
   public String edit_task(HttpServletRequest request, ModelMap model)
   {
	   int id = Integer.parseInt( request.getParameter("id"));
	   TODO_Task t = _dao.get_task(id);
	   //ModelAndView model = new ModelAndView("new_task_form");
	   model.addAttribute("task", t);
	   return "new_task_form";
	   //return model;
	   
   }
   
   
}
